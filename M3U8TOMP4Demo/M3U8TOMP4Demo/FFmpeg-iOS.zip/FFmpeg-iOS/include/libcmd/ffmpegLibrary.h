//
//  ffmpegLibrary.h
//  ffmpegLibrary
//
//  Created by Beryter on 2019/7/16.
//  Copyright © 2019 Beryter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ffmpegLibrary : NSObject
+ (void)convertTS2MP4:(NSString *)tsPath desPath:(NSString *)desPath completion:(void(^)(void))completion;
@end
